const audio = document.getElementById('audio');
const playBtn = document.getElementById('play-btn');
const pauseBtn = document.getElementById('pause-btn');
const animation = document.getElementById('animation');

playBtn.addEventListener('click', () => {
    audio.play();
    playBtn.classList.add('hidden');
    pauseBtn.classList.remove('hidden');
    animation.style.display = 'block';
});

pauseBtn.addEventListener('click', () => {
    audio.pause();
    pauseBtn.classList.add('hidden');
    playBtn.classList.remove('hidden');
    animation.style.display = 'none';
});
const volumeSlider = document.getElementById('volume-slider');

volumeSlider.addEventListener('input', (e) => {
    audio.volume = e.target.value;
});
